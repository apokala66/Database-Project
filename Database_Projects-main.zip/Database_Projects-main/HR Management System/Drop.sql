DROP table department CASCADE CONSTRAINTS;

DROP table designation CASCADE CONSTRAINTS;


DROP table PROJECTS CASCADE CONSTRAINTS;


DROP table ASSET CASCADE CONSTRAINTS;

DROP table skills CASCADE CONSTRAINTS;


DROP table hrms_employee_details CASCADE CONSTRAINTS;


DROP table hrms_employee_projects CASCADE CONSTRAINTS;


DROP table hrms_employee_salary CASCADE CONSTRAINTS;


DROP table hrms_employee_asset CASCADE CONSTRAINTS;



DROP table hrms_employee_trainings CASCADE CONSTRAINTS;





DROP table hrms_employee_leaves CASCADE CONSTRAINTS;


DROP table hrms_employee_attendance CASCADE CONSTRAINTS;



DROP table hrms_kra_kpi CASCADE CONSTRAINTS;


DROP table WAGES CASCADE CONSTRAINTS;

DROP table hrms_employee_details_log ;

    



